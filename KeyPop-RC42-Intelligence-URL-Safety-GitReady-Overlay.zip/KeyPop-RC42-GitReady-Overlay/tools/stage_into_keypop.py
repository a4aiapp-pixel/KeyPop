#!/usr/bin/env python3
"""Stage the RC42 source overlay into a real KeyPop checkout safely.

Default is a read-only dry run. --apply copies only missing files and never
modifies AetherImeService or Android version/signing configuration. It must be
followed by actual suggestion-strip integration and emulator verification.
"""
import argparse
import hashlib
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ALLOWED = [Path("app/src"), Path("verification"), Path("docs"), Path(".github/workflows")]

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True, help="Path to an existing KeyPop checkout")
    parser.add_argument("--apply", action="store_true", help="Write new files; default only checks")
    args = parser.parse_args()
    repo = args.repo.expanduser().resolve()
    markers = [repo / "app/build.gradle.kts",
               repo / "app/src/main/java/com/aetherkeys/keyboard/AetherImeService.kt"]
    if not all(p.is_file() for p in markers):
        print("ERROR: --repo must point to a complete KeyPop Android checkout", file=sys.stderr)
        return 2
    files = sorted(p for prefix in ALLOWED for p in (ROOT / prefix).rglob("*") if p.is_file())
    if not files:
        print("ERROR: overlay has no files", file=sys.stderr)
        return 2
    conflicts, additions = [], []
    for path in files:
        relative = path.relative_to(ROOT)
        target = repo / relative
        if target.is_file():
            a = hashlib.sha256(path.read_bytes()).digest()
            b = hashlib.sha256(target.read_bytes()).digest()
            if a != b: conflicts.append(str(relative))
        else: additions.append((path, target, str(relative)))
    print(f"Staging scan: {len(additions)} new files, {len(conflicts)} conflicts, "
          f"{len(files)-len(additions)-len(conflicts)} already identical")
    if conflicts:
        print("STOP: Existing files differ. No changes made. Conflicts:", *conflicts, sep="\n - ")
        return 3
    if args.apply:
        for source, target, relative in additions:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            print("ADDED", relative)
    else:
        print("Dry run. Re-run with --apply to add files.")
    host = markers[1].read_text(encoding="utf-8")
    if "KeyPopAdaptiveServiceController" not in host:
        print("INTEGRATION STILL REQUIRED: AetherImeService has not been wired to the "
              "adaptive controller or suggestion taps. See docs/ANDROID_SERVICE_HOOKS.md.")
    print("This stage operation neither uploads to GitHub nor claims an Android APK build.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
