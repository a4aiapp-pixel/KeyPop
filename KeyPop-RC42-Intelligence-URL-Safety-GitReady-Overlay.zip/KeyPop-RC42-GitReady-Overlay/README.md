# KeyPop RC42 — Coordinated Personal Intelligence (Git-ready source overlay)

**Build state:** Kotlin/JVM model logic tested locally; **NOT uploaded to GitHub, integrated into the existing IME UI, Android compiled, or published as an APK**. The live GitHub connector currently rejects access with `link_id must identify an eligible linked account`. No local KeyPop repository/Android SDK is available. This ZIP is designed to be **staged into an existing KeyPop checkout**, not uploaded as an APK or treated as a complete replacement project.

**Target repository:** `amjadrajamemon/KeyPop` — integrate on a dedicated RC42 branch based on the most recent verified RC40 release. Do not modify the existing published RC40 artifacts or production signing keys. Preserve RC38 suggestion auto-spacing, RC39 Backspace, and RC40 WhatsApp Enter behavior.

## Included

- `KeyPopAdaptiveLanguageModel.kt`: offline context/grammar heuristics, personal phrase and word learning, recency-frequency ranking, Unicode words, caps, per-category address consent.
- `KeyPopAdaptiveCandidatePlanner.kt`: token replacement plans and unified candidate deduplication.
- `KeyPopAdaptiveEditorPolicy.kt`: personal-memory eligibility for sensitive, incognito and excluded fields, with adaptive predictions suppressed in URL/email fields.
- `KeyPopUrlEditingPolicy.kt`: explicit URL/email and embedded URL-token protection against automatic correction, spacing, punctuation and suggestion replacement.
- `docs/URL_EDITING_REGRESSIONS.md`: mandatory host-IME integration requirements for URL truncation/non-editable behavior, plus long-URL and cursor editing tests.
- `KeyPopAdaptiveHistoryStore.kt`: AES-GCM encrypted, bounded and atomic app-private phrase-memory persistence via Android Keystore.
- `KeyPopAdaptiveServiceController.kt`: service-facing async controller, session invalidation, opt-in word/phrase learning, erasure and background I/O.
- `KeyPopAdaptiveSettingsDialog.kt`: opt-in settings UI component; **the host activity must wire it to service erasure and add per-app exclusion UX**.
- JUnit and Android instrumentation tests and `verification/RunRc42Regression.kt`: standalone Kotlin regression harness and URL editing baseline on Android.
- `tools/stage_into_keypop.py`: guarded staging helper that checks for an actual KeyPop checkout and refuses to overwrite differing files.
- `.github/workflows/rc42-intelligence-source-gates.yml`: independent Android compile/unit/lint gate; it does **not publish APKs** and warns if the real keyboard suggestion strip is not connected.
- `docs/ANDROID_SERVICE_HOOKS.md`: integration and privacy/runtime verification contract.

## Current local verification

Run `bash verification/run_local_checks.sh` with Java and `kotlinc` installed. Result: **73 source-level assertions passed** for grammar, phrase recall, privacy consent, selection planning and candidate merging. Android compiled packages, real editor focus, Chrome and WhatsApp behavior are **not verified** for RC42. This is not a claim of superiority to Gboard or full neural-language-model functionality. It does not include neural weights or on-device AI inference.

## Staging into the repository

With a complete, locally checked-out copy of `amjadrajamemon/KeyPop`:

```bash
# From a fresh branch of the real KeyPop checkout
python3 KeyPop-RC42-GitReady-Overlay/tools/stage_into_keypop.py --repo /path/to/KeyPop
python3 KeyPop-RC42-GitReady-Overlay/tools/stage_into_keypop.py --repo /path/to/KeyPop --apply
# Review docs/ANDROID_SERVICE_HOOKS.md in the checkout, then wire the hooks.
# Do not mark the release as complete until visible suggestions pass emulator tests.
```

The script *adds* new files, never overwrites existing service/Android configuration. If a ZIP was simply uploaded to GitHub as one file, it is **not installed into source**; the contents must be extracted/staged and committed. Place/unzip the overlay beside the checkout or call the script from its extracted location. GitHub does not extract uploaded ZIP archives as repository source files: commit the staged directory contents to a branch.

After completing the live IME integration, run:

```bash
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest
```

Only after manual WhatsApp, Chrome, real Android IME suggestion-strip instrumentation, and release-signature/upgrade checks should a genuine RC42 prerelease be published. If a new debug signature is used, it cannot update RC40 in place. An upgrade-safe package requires a compatible, securely held signing certificate.

**Privacy:** Personal learning is OFF by default. The keyboard cannot retrieve historical WhatsApp conversations; it only learns newly confirmed text with explicit consent and editor eligibility. The source implementation must not be enabled in production before the above integration and test gates are complete.
